<?php 
include("config.php");
if (isset($_POST['submit'])) {
$marks = mysqli_real_escape_string($db,$_POST['marks']);
$subjects= $_POST['subject'];
$farming= $_POST['farming'];
foreach ($subjects as $i) {
$subject = $i;
$sql = "INSERT INTO `test` (`subjects`, `marks`) VALUES ('".mysqli_real_escape_string($db,$subject)."', '$marks')";
mysqli_query($db,$sql);
}
$sql1 = "INSERT INTO `test` (`marks`) VALUES ('$marks')";
mysqli_query($db,$sql1);
}
?>