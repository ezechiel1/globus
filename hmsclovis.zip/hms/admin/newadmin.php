<?php
  
    include("config.php");
    //DepartmentID and Department name
   
    $msg='';
    if(isset($_POST['addadmin'])){
        $Name=htmlspecialchars($_POST['name']);
        $Email=htmlspecialchars($_POST['email']);
        $password=htmlspecialchars($_POST['password']);
        $password=sha1($password);
        $namep=$_FILES['cv']['name'];
            if(isset($namep) && $namep!='')
            {   
                $ext=strrchr($namep, '.');
                $tmp_name = $_FILES['cv']['tmp_name'];
                $logo='cv/'.$namep;
                $valables= array('.png','.jpg','.jpge');
                
                if(in_array($ext, $valables)){
                 if(move_uploaded_file($tmp_name, $logo)){
        $NewEmployee=mysqli_query($connect,"INSERT INTO admin(name,email,password,profile,cdate) values('$Name','$Email','$password','$logo',NOW())");
                if($NewEmployee){
                        $msg='<span style="color:green;">New admin is added</span>';
                    }

                else{
                        $msg='<span style="color:red;">One field is Missing</span>';
                }
              }
                else{
                    $msg='<span style="color:red;">There was  an arror while uploading the document !</span>';
                }
              }
                else{
                    $msg='<span style="color:red;">The format is invalid !</span>';
                }
            }
    }
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Hiring management system</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="../icon-employees_orig.png">
    <link rel="shortcut icon" href="../icon-employees_orig.png">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
     <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>

    <?php
        include("header.php")
    ?>
     
         <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                   <a href="index.html" style="color:#000; font-size:25px; font-weight:500;">
                        New admin
                    </a>
                </div>
                <div class="login-form">
                    <form method="post" enctype="multipart/form-data">
                        <div class="col-md-12"><center> <small class="text-danger"><?php echo $msg;?></small> </center></div>
                        <div class="form-group">
                            <label>Name </label>
                            <input type="text" class="form-control" placeholder="" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" placeholder="" name="email" required>
                        </div>
                         <div class="form-group">
                            <label>Email</label>
                            <input type="file" class="form-control" placeholder="" name="cv" required>
                        </div>
                         <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" placeholder="" name="password" required>
                        </div>
                        <div class="divbutton">
                            <button type="submit" class="btn btn-primary" name="addadmin">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    
    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
