<?php
session_start();
include("config.php");
if($_SESSION['id']=='') header("location: index.php");
$ID=$_SESSION['id'];
$category=$_SESSION['category_id'];
// $type=$_SESSION['type'];

if($category==1){
    $select = mysqli_query($connect,"SELECT * FROM admin WHERE adminID = '$ID'");
    $get = mysqli_fetch_array($select);
    $name = $get['name'];
}

?>
<style>
    .modal-backdrop.show{
        opacity: unset !important;
    }
    .modal-backdrop.show{
        position: unset !important;
    }
</style>
<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="landing.php" style="font-weight:500;">HMS admin</a>
                <a class="navbar-brand hidden" href="./"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-glass"></i>Departement</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="newdepartement.php">Add New</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="managedepartement.php">List Departement</a></li>
                           
                        </ul>
                    </li>
                    <h3 class="menu-title"></h3>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-dashboard"></i>Admin</a>
                         <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="newadmin.php">Add Admin</a></li>
<!--                            <li><i class="menu-icon fa fa-sign-in"></i><a href="manageadmin.php">List Admin</a></li>-->
                           
                        </ul>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                    <li class="menu-item-has-children dropdown">
                        <a href="manageemployee.php" class="dropdown-toggle"> <i class="menu-icon fa fa-users"></i> Employees Request</a> 
                       
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                     <li class="menu-item-has-children dropdown">
                        <a href="approved_employees.php" class="dropdown-toggle"> <i class="menu-icon fa fa-users"></i> Aprouved employees</a>
                       
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                     <li class="menu-item-has-children dropdown">
                        <a href="pending_employees.php" class="dropdown-toggle"> <i class="menu-icon fa fa-fort-awesome"></i> Pending Employees</a>
                       
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                      <li class="menu-item-has-children dropdown">
                        <a href="denied_employees.php" class="dropdown-toggle"> <i class="menu-icon fa fa-th"></i> Deneid Employees</a>
                       
                    </li>
                   <h3 class="menu-title"></h3><!-- /.menu-title -->
                   
                     <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-dashboard"></i>Examination</a>
                         <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="newtest.php">Create test</a></li>
                            <li><i class="menu-icon fa fa-sign-in"></i><a href="manegetest.php">manage test</a></li>
                           
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                       
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                      
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" style="width:30px;height:30px;" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                             <a href="#">
                             <span style="color:green; font-weight:500;"> <?php echo $name;?></span>
                        </a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                   

                </div>
            </div>

        </header><!-- /header -->