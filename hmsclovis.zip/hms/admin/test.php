<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <head>
    <title>Trial
    </title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <form method="POST" action="name.php">
      <select id="multiselect" name="farming[]" multiple="multiple" required>
        <option value="Irrigation">Irrigation
        </option>
        <option value="Fertilizer">Fertilizer
        </option>
        <option value="Pesticide">Pesticide
        </option>
        <option value="Herbicide">Herbicide
        </option>
        <option value="Row-planting">Row-planting
        </option>
        <option value="Broad-casting">Broadcasting
        </option>
        <option value="Pure-stand">Pure Stand
        </option>
        <option value="Inter-cropping">Inter cropping
        </option>
      </select>
      <select id="multiselect" name="subject[]" multiple="multiple" required>
        <option value="Irrigation">Technology
        </option>
        <option value="Fertilizer">Science
        </option>
        <option value="Pesticide">Arts
        </option>
        <option value="Herbicide">Agric
        </option>
        <option value="Row-planting">Math
        </option>
        <option value="Broad-casting">BIZ
        </option>
      </select>
      <div class="input-group">
        <label>Marks
        </label>
        <input type="number" name="marks">		
      </div>
      <button type="submit" name="submit" class="btn">SUBMIT
      </button>	
    </form>
  </body>
</html>
