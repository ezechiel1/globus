<?php
if(!isset($_GET['request'])) header('location: manageemployees.php');
$doc=$_GET['request'];
$docPath='../'.$doc;
//Code to Download any file
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$doc."");
readfile($docPath);
?>