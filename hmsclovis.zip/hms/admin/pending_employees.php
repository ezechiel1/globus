<?php
    include("config.php");
    $msg='';
    if(isset($_POST['denied'])){
        $id=$_POST['idd'];
        $query=mysqli_query($connect,"UPDATE employees set status=3 where employee_id='$id'");
        if($query): $msg = 'Operation done succesfully!';
        else: $msg = 'Some Errors ocured!';
        endif;
    }
    if(isset($_POST['pending'])){
        $id=$_POST['idd'];
        $query=mysqli_query($connect,"UPDATE employees set status=1 where employee_id='$id'");
        if($query): $msg = 'Operation done succesfully!';
        else: $msg = 'Some Errors ocured!';
        endif;
    }
    if(isset($_POST['approve'])){
        $id=$_POST['idd'];
        $query=mysqli_query($connect,"UPDATE employees set status=2 where employee_id='$id'");
        if($query): $msg = 'Operation done succesfully!';
        else: $msg = 'Some Errors ocured!';
        endif;
    }
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Hiring management system</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <!-- Left Panel -->

   <?php
        include("header.php")
    ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Data Table</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Employee Name </th>
                                            <th>Employee email</th>
                                            <th>Empoyee Department</th>
                                            <th>Employee Number</th>
                                            <th>Edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
                                            //selectb from database
                                            $querySel=mysqli_query($connect,"SELECT * FROM employees inner join department on department.departID=employees.department_id where employees.status=1"); //deja denied
                                            if(mysqli_num_rows($querySel)>0):
                                            while($show=mysqli_fetch_array($querySel)):
                                            ?>
                                       
                                        <tr>
                                            <td><?php echo $show['name'];?></td>
                                            <td><?php echo $show['email'];?></td>
                                            <td><?php echo $show['depart_name'];?></td>
                                            <td><?php echo $show['number'];?></td>
                                            <td><a class="btn btn-default"  data-toggle="modal" <?php echo 'data-target="#approuve'.$show['employee_id'].'"';?> style="background-color:#fff; color:green;">aprouve</a> <a class="btn btn-primary" data-toggle="modal" <?php echo 'data-target="#dinied'.$show['employee_id'].'"';?> style="background-color:red; color:#fff;">x</a></td>
                                        </tr>
                                         <section id="models">
                                             <div <?php echo 'id="approuve'.$show['employee_id'].'"';?> class="modal fade" role="dialog">
                                              <div class="modal-dialog  modal-md">
                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" onclick="pauseVid()">&times;</button>
                                                   </div>
                                                  <div class="modal-body">
                                                     <div class="login-content">
               
                                                        <div class="login-form">
                                                            <form method="post" action="">
                                                                <div class="col-md-12">
                                                  <input type="hidden" value="<?php echo $show['employee_id'];?>" name="idd" class="form-control" >
                                                                     <div class="form-group">
                                                                        <center><label>Do you confirm to approve this employee? </label></center>
                                                                     </div>
                                                                </div>
                                                                
                                                               <center>
                                                                    <div class="">
                                                                        <button type="submit" name="approve" class="btn btn-primary">Approves</button>
                                                                        <button type="submit" data-dismiss="modal" name="Exit" class="btn btn-primary">Exit</button>
                                                                    </div>
                                                                </center>
                                                                
                                                            </form>
                                                        </div>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                            </div>
                                        </section>
                                
                                        <section id="models">
                                             <div <?php echo 'id="dinied'.$show['employee_id'].'"';?> class="modal fade" role="dialog">
                                              <div class="modal-dialog  modal-md">
                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" onclick="pauseVid()">&times;</button>
                                                   </div>
                                                  <div class="modal-body">
                                                     <div class="login-content">
               
                                                        <div class="login-form">
                                                            <form method="post" action="">
                                                                <div class="col-md-12">
                                                   <input type="hidden" value="<?php echo $show['employee_id'];?>" name="idd" class="form-control" >
                                                                     <div class="form-group">
                                                                        <center><label>Do you confirm to Dinied this employee? </label></center>
                                                                     </div>
                                                                </div>
                                                                
                                                               <center>
                                                                    <div class="">
                                                                        <button type="submit" name="denied" class="btn btn-primary">Yes</button>
                                                                        <button type="submit" data-dismiss="modal" name="Exit" class="btn btn-primary">Exit</button>
                                                                    </div>
                                                                </center>
                                                                
                                                            </form>
                                                        </div>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                            </div>
                                        </section>
                                         <?php
                                           endwhile;
                                        endif;
                                
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
