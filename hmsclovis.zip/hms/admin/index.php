<?php
    session_start();
    include("config.php");
    $msg='';
    if(isset($_POST['logadmin'])){
        $email=htmlspecialchars($_POST['email']);
        $password=sha1($_POST['password']);
        $logAdmin=mysqli_query($connect,"SELECT * FROM admin where email='$email' and password='$password' ");
        if(mysqli_num_rows($logAdmin)>0)//exists admin
        {
            $getInfo=mysqli_fetch_array($logAdmin);

                $_SESSION['category_id']=1;
                if($getInfo['admin_pin']==0)//if he/she has not change his/her default pass
                {
                    $_SESSION['id']=$getInfo['adminID'];
                    header("location: reset.php");
                }
                else if($getInfo['admin_pin']==1)//if he/she is allowed to sign into the system
                {
                    $_SESSION['id']=$getInfo['adminID'];
                    $_SESSION['type']=$getInfo['admin_type'];
                    header("location: landing.php");
                }

        }
         else //if the entered infromarions dont match (correspndre])
            {
                $msg='Email Address or Password are Incorrect!';
            }
    }
      
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Hiring management system</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="bg-dark">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="index.html" style="color:#fff;">
                        HMS Admin
                    </a>
                </div>
                <div class="login-form">
                    <form method="post">
                         <div class="col-md-12"><center> <small class="text-danger"><?php echo $msg;?></small> </center></div>
                        <div class="form-group">
                            <label>Email  </label>
                            <input type="email" class="form-control" placeholder="" name="email">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" placeholder="" name="password">
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox"> Remember Me
                            </label>
                        </div>
                        <div class="divbutton">
                            <button type="submit" class="btn btn-primary" name="logadmin">login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
