<?php
$host='localhost';
$user='root';
$password='';
$db='hms2';
//query to connect to the db
$connect=mysqli_connect($host,$user,$password,$db);

?>