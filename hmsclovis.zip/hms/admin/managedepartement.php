<?php
   
        include("config.php");
        if(isset($_POST['edit_depart'])){
            $Name=htmlspecialchars($_POST['name']);
            $Number=htmlspecialchars($_POST['number']);
             //$description=htmlspecialchars($_POST['description']);
            //keep the adminID from the form
            $idd=$_POST['idd'];
            //query to check data from the database

            $NewDepart=mysqli_query($connect,"UPDATE department SET depart_name='$Name',employee_number='$Number' WHERE departID='$idd' ");
            if($NewDepart){
                echo '<script>alert("Departement updated successfully!")</script>';
            }
        }
      
        if(isset($_POST['delete_depart'])){
            //keep the adminID from the form
            $idd=$_POST['idd'];
            //query to check data from the database
            if($idd==$ID){
                echo '<script>alert("Impossible to perform this Operation!")</script>';
            }
            else {
                $NewDepart=mysqli_query($connect,"DELETE FROM depatment WHERE departID='$idd' ");
                if($NewEvent){
                  echo '<script>alert("Departement Deleted successfully!")</script>';
                }
                else{
                  echo '<script>alert("Some Error Occured. Please try again!")</script>';
            }
            //correspondre}
            }
        }
   
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Hiring management system</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <!-- Left Panel -->

   <?php
        include("header.php")
    ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Data Table</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Departement Name </th>
                                            <th>Required Number</th>
                                            <th>Edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
                                            //selectb from database
                                            $querySel=mysqli_query($connect,"SELECT * FROM department");
                                            while($show=mysqli_fetch_array($querySel))
                                            {
                                            ?>
                                       
                                        <tr>
                                            <td><?php echo $show['depart_name'];?></td>
                                            <td><?php echo $show['employee_number'];?></td>
                                            
                                            <td><a class="btn btn-default" data-toggle="modal" <?php echo 'data-target="#alladmin'.$show['departID'].'"';?> style="background-color:#2c3e50; color:#fff;">Edit</a></td>
                                        </tr>
                                        </tr>
                                         <section id="models">
                                             <div <?php echo 'id="alladmin'.$show['departID'].'"';?> class="modal fade" role="dialog">
                                              <div class="modal-dialog  modal-md">
                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" onclick="pauseVid()">&times;</button>
                                                   </div>
                                                  <div class="modal-body">
                                                     <div class="login-content">
               
                                                        <div class="login-form">
                                                            <form method="post" action="">
                                                                <input type="hidden" value="<?php echo $show['departID'];?>" name="idd" class="form-control" >
                                                                <div class="col-md-12">
                                                                     <div class="form-group">
                                                                        <label> Name</label>
                                                                        <input type="text" name="name" class="form-control" value="<?php echo $show['depart_name'];?>" required>
                                                                    </div>
                                                                </div>
                                                               
                                                                 <div class="col-md-12">
                                                                     <div class="form-group">
                                                                        <label> Number</label>
                                                                        <input type="text" name="number" class="form-control" value="<?php echo $show['employee_number'];?>" required>
                                                                    </div>
                                                                </div>
                                                                 
                                                                
                                                                 
                                                              
                                                            
                                                                <div class="login-btn">
                                                                    <button type="submit" name="edit_depart" class="btn btn-primary btn-flat m-b-30 m-t-30">change</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                            </div>
                                        </section>
                                         <section id="models">
                                             <div <?php echo 'id="delete'.$show['departID'].'"';?> class="modal fade" role="dialog">
                                              <div class="modal-dialog  modal-md">
                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" onclick="pauseVid()">&times;</button>
                                                   </div>
                                                  <div class="modal-body">
                                                     <div class="login-content">
               
                                                        <div class="login-form">
                                                            <form method="post" action="">
                                                                <div class="col-md-12">
                                                   <input type="hidden" value="<?php echo $show['departID'];?>" name="idd" class="form-control" >
                                                                     <div class="form-group">
                                                                        <center><label>Do you confirm to delete this event? </label></center>
                                                                     </div>
                                                                </div>
                                                                
                                                               <center>
                                                                    <div class="">
                                                                        <button type="submit" name="delete_admin" class="btn btn-primary">Delete</button>
                                                                        <button type="submit" data-dismiss="modal" name="Exit" class="btn btn-primary">Exit</button>
                                                                    </div>
                                                                </center>
                                                                
                                                            </form>
                                                        </div>
                                                    </div>
                                                  </div>
                                                </div>

                                              </div>
                                            </div>
                                        </section>
                                
                                         <?php
                                                
                                        }
                                        ?> 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
